<?php 
Route::get('service', 'HomeController@index');
Route::get('about-us', 'HomeController@index');
Route::get('contact-us', 'HomeController@index');
Route::get('privacy', 'HomeController@index');
Route::get('toc', 'HomeController@index');
Route::get('backend', 'HomeController@index');
?>