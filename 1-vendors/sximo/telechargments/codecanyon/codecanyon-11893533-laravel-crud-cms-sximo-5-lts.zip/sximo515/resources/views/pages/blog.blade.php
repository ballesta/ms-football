<?php 

	echo app\Http\Controllers\BlogadminController::blog();

?>