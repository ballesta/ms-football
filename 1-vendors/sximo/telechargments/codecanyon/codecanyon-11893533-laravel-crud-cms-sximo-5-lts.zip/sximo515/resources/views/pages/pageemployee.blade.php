<?php use \App\Http\Controllers\EmployeeController;
echo EmployeeController::display(); ?> 