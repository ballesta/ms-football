
<div class="container">

<div class="row">
		
		<div class="col-md-3 ">
			<ul class="nav nav-stacked nav-pills">
								<li class="active ">
					<a href="#">General Question</a>
				</li>
								<li class="">
					<a href="#">Installation</a>
				</li>
								<li class="">
					<a href="#">Membership</a>
				</li>
								<li class="">
					<a href="#">Other Question</a>
				</li>
								<li class="">
					<a href="#">Licences</a>
				</li>
								<li class="">
					<a href="#">New Items</a>
				</li>
						
			</ul>	
		</div>
		<div class="col-md-9">
			<div id="accordion" class="panel-group">
											  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#1" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 What is Sximo Builder ?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="1">
					  <div class="panel-body">
						<p>Lorem ipsum dolor sit <span style="font-weight: bold;"><span style="color: rgb(255, 0, 0);">amet</span></span>, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur <br></p>

<p>adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. </p>					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#2" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 What are the applications type created by Sximo Builder ?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="2" style="height: 0px;">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#3" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 In which language are the applications generated ?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="3" style="height: 0px;">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#4" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 What are the supported databases?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="4">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#5" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 Which operating systems can the generated programs run?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="5">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#6" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 What are the requirements to run Sximo Builder ?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="6">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#7" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 How do I learn about Sximo ?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="7">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#8" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 How can I access the development area ?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="8">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  				  <div class="panel panel-default faq-panel">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a href="#9" data-parent="#accordion" data-toggle="collapse" class="collapsed">
						 Can I access the development area through the internet?						</a>
					  </h4>
					</div>
					<div class="panel-collapse collapse" id="9">
					  <div class="panel-body">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur

adipiscing elit. Morbi id neque quam. Aliquam sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id neque quam. Aliquam
sollicitudin venenatis ipsum ac feugiat. Vestibulum ullamcorper sodales nisi nec condimentum. Mauris convallis mauris at pellentesque volutpat. 					  </div>
					</div>
				  </div>
				  	
				  
			</div>
		</div>
	
	</div>
	
</div>	