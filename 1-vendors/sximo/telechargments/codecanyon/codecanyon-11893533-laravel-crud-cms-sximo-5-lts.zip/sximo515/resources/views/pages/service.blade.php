
	<section>
		<div class="container">	
			<p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc vehicula lacinia. Proin adipiscing porta tellus, ut feugiat nibh adipiscing sit amet.</p>
		
			<div class="divider divider-center divider-color"><!-- divider -->
				<i class="fa fa-chevron-down"></i>
			</div>
		</div>
	</section>	
	
	
	<section class="services" id="why">
	<div class="container">
	  <div class="row">
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-flag"></i>Service </h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-ban"></i> Service</h4>
		 Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-arrows-alt"></i> Service</h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-microphone"></i> Service</h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-pencil"></i> Service</h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-eye"></i> Services</h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-gamepad"></i> Service</h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-desktop"></i> Service</h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
		<div class="col-md-4 col-sm-6">
		  <h4><i class="fa fa-search"></i> Service</h4>
		  Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.
		</div>
	  </div>
	  </div>	
	</section>
