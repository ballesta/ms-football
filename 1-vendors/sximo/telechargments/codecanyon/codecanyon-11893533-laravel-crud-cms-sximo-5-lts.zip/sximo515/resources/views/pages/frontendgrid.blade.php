<div class="container">
 <?php
 use \App\Http\Controllers\SampleController;
 echo SampleController::display();
 ?>

</div>